<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
namespace block_weather;
defined('MOODLE_INTERNAL') || die();
/**
 * Helper class for handling communication with EduTech API.
 * 
 * @package block_weather
 * @copyright 2023 EduTech
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class weather{
    /*Endpoint to API conection*/
    private static $queryweatherendpoint = "http://api.weatherapi.com/v1/current.json?";
    /*Token validator on Edutech website*/
    private static $apikey = "234cd0bc54734e8faac60544231901";
    /**
     * Get all learning objects by page and filters.
     *
     * @param integer|string $page
     * @param array $filters array will be converted to URL-encoded query string.
     * @throws \block_exception
     * @return array
     */
    public static function get_weather($location){
        $url = self::$queryweatherendpoint;
        $key = self::$apikey;
        $requester = new requester($url . "key=$key" . "&q=$location");
        $response = $requester->get();
        if ($requester->response_code != 200){
            $response->failed = true;
        }
        return $response;
        
    }
}